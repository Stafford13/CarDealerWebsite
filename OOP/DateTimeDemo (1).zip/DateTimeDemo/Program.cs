﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DateTimeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CharacterManager.Run();
            //ListDemo.Run();
            //TimeDemo.Run();
            Console.ReadLine();
        }
    }
}
