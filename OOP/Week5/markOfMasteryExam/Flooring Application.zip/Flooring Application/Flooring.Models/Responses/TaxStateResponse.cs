﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flooring.Models.Response
{
    public class TaxStateResponse : Response
    {
        public FlooringTax TaxRate; 
    }
}
