﻿using Flooring.BLL;
using Flooring.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flooring.Tests
{
    [TestFixture]
    public class AddOrderTest
    {
        [Test]
        public void TestAdd()
        {
            Assert.AreEqual(true, false);
        }
    }
}
